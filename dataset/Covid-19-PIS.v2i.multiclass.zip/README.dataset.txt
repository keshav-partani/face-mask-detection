# Covid-19-PIS > 2023-03-31 12:14pm
https://universe.roboflow.com/pyimagesearch/covid-19-pis

Provided by a Roboflow user
License: MIT

